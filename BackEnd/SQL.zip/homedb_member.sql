-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: homedb
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `memberid` varchar(30) NOT NULL,
  `pwd` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `name` varchar(45) NOT NULL,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `auth` enum('nomal','admin') NOT NULL DEFAULT 'nomal',
  `token` varchar(1000) DEFAULT NULL,
  `confirm_ans` varchar(1000) DEFAULT NULL,
  `confirm_question` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`memberid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('@2545783107','KS4xqzJbcd00kx9fbCJ4h-gprcmgE','NULL','박정희','2022-11-24 01:25:37','nomal',NULL,NULL,NULL),('@2547862444','Kgz_CO1xoppSpaRtmzabyI_9EkbSa','xvsgxv@gmail.com','장정민','2022-11-24 05:04:21','nomal',NULL,NULL,NULL),('@2547865199','eNoa4sK5VkTOzfDjOELWGv2FsHI5l','jalee4930@gmail.com','이재욱','2022-11-24 05:06:20','nomal',NULL,NULL,NULL),('1234','1234','1234@gmail.com','1234','2022-11-24 05:15:30','nomal',NULL,'1234','1234'),('aa','aa','aa@naver.com','aa','2022-11-24 02:33:22','nomal',NULL,'a초등학교','출신 초등학교'),('aaa','qqq','a@c.co','fd','2022-11-24 05:04:08','nomal',NULL,'a','a'),('aaaa','aaaa','aaaa','aaaa','2020-10-12 00:51:24','nomal',NULL,NULL,NULL),('abcbbb','aa','saf@naver.com','asdf','2022-11-24 02:16:26','nomal',NULL,'321','123'),('admin','admin','admin@naver.com','admin','2022-10-12 00:51:24','admin',NULL,NULL,NULL),('bb','bb','bb@naver.com','bb','2022-11-24 02:34:04','nomal',NULL,'b초등학교','출신초등학교는??'),('dksxogus1012','1111','q@ssafy.com','섹시태봉','2022-11-24 03:03:35','nomal',NULL,'사생활침해','내 핸드폰 번호는?'),('jul','123123','ocean@naver.com','찌유르','2022-11-24 02:59:11','nomal',NULL,'14반','싸피 1학기 몇반'),('test1111','1111','abc@naver.com','나이키','2022-11-24 02:27:23','nomal',NULL,'이키','우리집 고양이 이름은?');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-24 16:00:44
