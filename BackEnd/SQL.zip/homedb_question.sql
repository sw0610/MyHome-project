-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: homedb
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question` (
  `question_no` int NOT NULL AUTO_INCREMENT,
  `memberid` varchar(30) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `content` varchar(4000) NOT NULL,
  `createdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `isprivate` tinyint(1) DEFAULT '0',
  `isComplete` tinyint(1) DEFAULT '0',
  `hit` int DEFAULT '0',
  PRIMARY KEY (`question_no`),
  KEY `memberid` (`memberid`),
  CONSTRAINT `question_ibfk_1` FOREIGN KEY (`memberid`) REFERENCES `member` (`memberid`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (5,'aaaa','집갈래요','나만의 집을 원해\n나 집가고 싶어','2022-11-16 08:39:00',NULL,1,112),(6,'admin','봉쇄','봉쇄','2022-11-21 04:38:56',1,0,160),(10,'dksxogus1012','정희님 자고 있는건가요','아니네 일어나셨네','2022-11-24 03:05:06',1,1,26),(11,'@2547862444','울지마 바보야!','나 정말 괜찮아','2022-11-24 05:04:34',1,0,7),(12,'@2547865199','내 마니또 화이팅!!!','이거 예쁘네염','2022-11-24 05:06:46',1,0,10),(13,'jul','14반 화이팅','팅이화 반41','2022-11-24 05:10:40',1,1,13),(16,'1234','나는 배창민이 지난 밤에 한 일을 알고 있다','나는 배창민이 지난 밤에 한 일을 알고 있다','2022-11-24 05:15:59',1,0,4),(17,'bb','그럼 무엇을 할까요','b내용','2022-11-24 05:20:16',1,0,7),(18,'admin','밍','잉>?','2022-11-24 05:22:33',1,0,1),(19,'admin','ㅁㄴㄹㅇ','ㄹㄹ','2022-11-24 05:22:42',1,0,1);
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-24 16:00:43
